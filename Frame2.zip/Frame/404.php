<?php get_header(); ?>
<main class="mytheme-main">
  <div class="error-404" >
    <h2 >Error 404 - Not Found</h2>
    <p>お探しのページは見つかりませんでした。</p>
</div>
</main>

<?php get_sidebar(); ?>

<?php get_footer(); ?>
